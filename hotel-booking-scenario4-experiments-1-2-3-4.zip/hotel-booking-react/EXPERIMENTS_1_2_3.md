# Scenario 4 — Hotel Room Booking Web Application

## Experiment 1: Component Testing
- Test command: `npm test`
- Test framework: Vitest with Jest-style `describe`, `it`, and `expect` APIs, plus React Testing Library dependencies for UI tests.
- Test coverage in `src/__tests__/bookingUtils.test.jsx`: hotel data/card details, search, price/rating/amenity filters, guest validation, room cost/tax/service charge, booking confirmation and cancellation behavior.
- Note: Vitest is used instead of Jest because this is a Vite application; it provides the familiar Jest-style test API and integrates directly with Vite.

## Experiment 2: Optimization
- Login form is loaded with `React.lazy` and `Suspense` (code splitting).
- Hotel images use lazy loading and async decoding.
- PWA manifest and auto-update service worker are configured with `vite-plugin-pwa`.
- Booking controls include accessible labels and autocomplete hints.
- Authentication token stays in `sessionStorage`; logout clears it. Do not store real secrets or payment data in browser storage. The demo API endpoints do not provide real booking authorization or payment processing.

## Experiment 3: Deployment
- Production build: `npm run build`; preview locally with `npm run preview`.
- GitHub Pages: push to `main`, enable GitHub Pages with GitHub Actions as the source. Workflow: `.github/workflows/deploy-pages.yml`. The workflow uses repository base `/hotel-booking-react/`; rename the base if the repository has another name.
- Netlify: import the repository and deploy with `netlify.toml` (`npm run build`, publish `dist`).
- Vercel: import the repository; `vercel.json` defines build and SPA rewrites.
- After deploying, test search, filters, hotel details, room selection, booking summary, login, confirmation and cancellation. Use demo data only.
