
import { Link, NavLink } from "react-router-dom";

function Header() {
  return (
    <header className="topbar">
      <Link className="brand" to="/">StayEasy</Link>
      <nav>
        <NavLink to="/">Home</NavLink>
        <NavLink to="/hotels">Hotels</NavLink>
        <NavLink to="/bookings">My Bookings</NavLink>
        <NavLink to="/login">Login</NavLink>
      </nav>
    </header>
  );
}

export default Header;
