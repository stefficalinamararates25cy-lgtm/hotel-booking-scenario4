
function FilterPanel({
  maxPrice,
  setMaxPrice,
  stars,
  setStars,
  wifi,
  setWifi
}) {
  return (
    <section className="panel filters">
      <label>
        Maximum price: ₹{maxPrice}
        <input
          type="range"
          min="1000"
          max="10000"
          step="500"
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
        />
      </label>

      <label>
        Star rating
        <select
          value={stars}
          onChange={(e) => setStars(Number(e.target.value))}
        >
          <option value="0">All ratings</option>
          <option value="3">3 stars and above</option>
          <option value="4">4 stars and above</option>
          <option value="5">5 stars only</option>
        </select>
      </label>

      <label>
        <input
          type="checkbox"
          checked={wifi}
          onChange={(e) => setWifi(e.target.checked)}
        />
        Wi-Fi available
      </label>
    </section>
  );
}

export default FilterPanel;
