
import { useLocation, useNavigate } from "react-router-dom";

export default function RoomSelection() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const hotel = state?.hotel;

  if (!hotel) {
    return (
      <div>
        <h2>Hotel details not found</h2>
        <button onClick={() => navigate("/hotels")}>
          Browse Hotels
        </button>
      </div>
    );
  }

  return (
    <div>
      <h2>Select Room</h2>
      <h3>{hotel.name}</h3>
      <p>Location: {hotel.location}</p>
      <p>Price: ₹{hotel.price} per night</p>

      <button
        onClick={() =>
          navigate("/booking/summary", {
            state: { hotel, roomPrice: hotel.price },
          })
        }
      >
        Continue Booking
      </button>
    </div>
  );
}
