
import { useState } from "react";
import { useBooking } from "../context/BookingContext";
import { useNavigate } from "react-router-dom";

function Payment() {
  const { hotel, customer, setConfirmed, total, selectedRoom, nights } =
    useBooking();
  const [method, setMethod] = useState("UPI");
  const navigate = useNavigate();

  function handleSubmit(e) {
    e.preventDefault();

    if (!hotel || !selectedRoom || !customer || nights < 1) {
      alert("Please complete your booking details first.");
      return;
    }

    setConfirmed({
      ...customer,
      hotel: hotel.name,
      room: selectedRoom.name,
      method,
      total
    });

    navigate("/booking/confirmation");
  }

  return (
    <form className="panel form-grid" onSubmit={handleSubmit}>
      <h2>Payment</h2>
      <p>Total amount: ₹{total}</p>

      <label>Payment method</label>
      <select
        value={method}
        onChange={(e) => setMethod(e.target.value)}
      >
        <option value="UPI">UPI</option>
        <option value="Card">Credit/Debit Card</option>
        <option value="Pay at Hotel">Pay at Hotel</option>
      </select>

      <p>Demo only — no real payment is processed.</p>
      <button type="submit">Confirm Reservation</button>
    </form>
  );
}

export default Payment;
