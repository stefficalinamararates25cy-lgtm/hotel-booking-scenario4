
import { useBooking } from "../context/BookingContext";

function BookingSummary() {
  const {
    hotel,
    room,
    checkIn,
    checkOut,
    guests,
    nights,
    roomCost,
    taxes,
    charges,
    total
  } = useBooking();

  if (!hotel) {
    return <p>Your booking is empty.</p>;
  }

  if (!room) {
    return <p>Please select a room.</p>;
  }

  return (
    <section className="panel">
      <h2>Booking Summary</h2>
      <p>Hotel: {hotel.name}</p>
      <p>Room: {room}</p>
      <p>Check-in: {checkIn || "Not selected"}</p>
      <p>Check-out: {checkOut || "Not selected"}</p>
      <p>Guests: {guests}</p>
      <p>Nights: {nights}</p>
      <hr />
      <p>Room cost: ₹{roomCost}</p>
      <p>Taxes: ₹{taxes}</p>
      <p>Additional charges: ₹{charges}</p>
      <h2>Total: ₹{total}</h2>
    </section>
  );
}

export default BookingSummary;
