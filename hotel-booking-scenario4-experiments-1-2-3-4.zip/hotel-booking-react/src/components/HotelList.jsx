
import HotelCard from "./HotelCard";

function HotelList({ hotels, onSelect }) {
  if (hotels.length === 0) {
    return <p>No hotels available.</p>;
  }

  return (
    <div className="hotel-grid">
      {hotels.map((hotel) => (
        <HotelCard
          key={hotel.id}
          hotel={hotel}
          onSelect={onSelect}
        />
      ))}
    </div>
  );
}

export default HotelList;
