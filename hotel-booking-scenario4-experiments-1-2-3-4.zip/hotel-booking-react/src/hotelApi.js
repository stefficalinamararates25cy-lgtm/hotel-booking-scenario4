
import axios from "axios";

const API_URL = "https://jsonplaceholder.typicode.com";

export async function fetchHotels() {
  const response = await axios.get(`${API_URL}/posts?_limit=10`);

  return response.data.map((item, index) => ({
    id: item.id,
    name: `Hotel ${index + 1} - ${item.title}`,
    location: ["Chennai", "Coimbatore", "Bangalore", "Madurai"][index % 4],
    price: 2000 + index * 500,
    available: index % 3 !== 0,
    description: item.body,
    rooms: [
      { id: 1, type: "Deluxe", price: 2000 + index * 500 },
      { id: 2, type: "Suite", price: 4000 + index * 500 },
    ],
  }));
}
