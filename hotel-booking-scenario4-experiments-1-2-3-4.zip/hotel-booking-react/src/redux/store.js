
import { configureStore } from "@reduxjs/toolkit";
import bookingReducer from "./bookingSlice";

const bookingMiddleware = (storeAPI) => (next) => (action) => {
  console.log("Booking Action:", action.type);

  const result = next(action);

  if (action.type.startsWith("booking/")) {
    const bookingState = storeAPI.getState().booking;

    try {
      localStorage.setItem(
        "hotelBooking",
        JSON.stringify(bookingState)
      );
    } catch (error) {
      console.error("Could not save booking:", error);
    }
  }

  return result;
};

const savedBooking = (() => {
  try {
    return JSON.parse(localStorage.getItem("hotelBooking")) || undefined;
  } catch {
    return undefined;
  }
})();

export const store = configureStore({
  reducer: {
    booking: bookingReducer,
  },
  preloadedState: savedBooking
    ? { booking: savedBooking }
    : undefined,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(bookingMiddleware),
});
