
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  selectedHotel: null,
  selectedRoom: null,
  checkIn: "",
  checkOut: "",
  guests: 1,
  customerName: "",
  customerPhone: "",
  bookings: [],
};

const bookingSlice = createSlice({
  name: "booking",
  initialState,

  reducers: {
    setHotel: (state, action) => {
      state.selectedHotel = action.payload;
    },

    setRoom: (state, action) => {
      state.selectedRoom = action.payload;
    },

    setDates: (state, action) => {
      state.checkIn = action.payload.checkIn;
      state.checkOut = action.payload.checkOut;
    },

    setGuests: (state, action) => {
      state.guests = action.payload;
    },

    setCustomer: (state, action) => {
      state.customerName = action.payload.name;
      state.customerPhone = action.payload.phone;
    },

    confirmBooking: (state) => {
      state.bookings.push({
        hotel: state.selectedHotel,
        room: state.selectedRoom,
        checkIn: state.checkIn,
        checkOut: state.checkOut,
        guests: state.guests,
        customerName: state.customerName,
        customerPhone: state.customerPhone,
      });
    },

    clearBooking: (state) => {
      state.selectedHotel = null;
      state.selectedRoom = null;
      state.checkIn = "";
      state.checkOut = "";
      state.guests = 1;
      state.customerName = "";
      state.customerPhone = "";
    },

    restoreBooking: (state, action) => {
      return { ...state, ...action.payload };
    },
  },
});

export const {
  setHotel,
  setRoom,
  setDates,
  setGuests,
  setCustomer,
  confirmBooking,
  clearBooking,
  restoreBooking,
} = bookingSlice.actions;

export default bookingSlice.reducer;
