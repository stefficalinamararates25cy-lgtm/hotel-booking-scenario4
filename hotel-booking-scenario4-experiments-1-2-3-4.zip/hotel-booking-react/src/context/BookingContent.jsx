
import {
  createContext,
  useContext,
  useState,
  useEffect,
  useMemo,
  useCallback
} from "react";

const BookingContext = createContext(null);

export function BookingProvider({ children }) {
  const [hotel, setHotel] = useState(null);
  const [room, setRoom] = useState("");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState(1);
  const [customer, setCustomer] = useState(null);
  const [confirmed, setConfirmed] = useState(null);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("stayBooking"));
      if (saved) {
        setHotel(saved.hotel || null);
        setRoom(saved.room || "");
        setCheckIn(saved.checkIn || "");
        setCheckOut(saved.checkOut || "");
        setGuests(saved.guests || 1);
        setCustomer(saved.customer || null);
        setConfirmed(saved.confirmed || null);
      }
    } catch {
      localStorage.removeItem("stayBooking");
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(
      "stayBooking",
      JSON.stringify({
        hotel, room, checkIn, checkOut,
        guests, customer, confirmed
      })
    );
  }, [hotel, room, checkIn, checkOut, guests, customer, confirmed]);

  const selectHotel = useCallback((selected) => {
    setHotel(selected);
    setRoom(selected.rooms?.[0]?.name || "");
    setConfirmed(null);
  }, []);

  const selectRoom = useCallback((selectedRoom) => {
    setRoom(selectedRoom);
  }, []);

  const updateGuests = useCallback((count) => {
    setGuests(count);
  }, []);

  const updateDates = useCallback((start, end) => {
    setCheckIn(start);
    setCheckOut(end);
  }, []);

  const clearBooking = useCallback(() => {
    setHotel(null);
    setRoom("");
    setCheckIn("");
    setCheckOut("");
    setGuests(1);
    setCustomer(null);
    setConfirmed(null);
    localStorage.removeItem("stayBooking");
  }, []);

  const nights = useMemo(() => {
    if (!checkIn || !checkOut || checkOut <= checkIn) return 0;
    return Math.round(
      (new Date(checkOut) - new Date(checkIn)) / 86400000
    );
  }, [checkIn, checkOut]);

  const selectedRoom = useMemo(
    () => hotel?.rooms?.find((item) => item.name === room) || null,
    [hotel, room]
  );

  const roomCost = (selectedRoom?.price || 0) * nights;
  const taxes = Math.round(roomCost * 0.12);
  const charges = hotel && nights > 0 ? 200 : 0;
  const total = roomCost + taxes + charges;

  const value = {
    hotel, room, checkIn, checkOut, guests,
    customer, confirmed, setCustomer, setConfirmed,
    selectHotel, selectRoom, updateGuests, updateDates,
    clearBooking, nights, selectedRoom,
    roomCost, taxes, charges, total
  };

  return (
    <BookingContext.Provider value={value}>
      {children}
    </BookingContext.Provider>
  );
}

export function useBooking() {
  const context = useContext(BookingContext);

  if (!context) {
    throw new Error(
      "useBooking must be used inside BookingProvider"
    );
  }

  return context;
}

export default BookingContext;
