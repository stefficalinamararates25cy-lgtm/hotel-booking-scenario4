import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { describe, it, expect, vi } from "vitest";
import HotelCard from "../components/HotelCard.jsx";

const hotel = { id: 1, name: "Grand Palace Hotel", location: "Chennai", stars: 5, amenities: ["Wi-Fi", "Pool"], price: 5000 };

describe("HotelCard component", () => {
  it("renders hotel details and price", () => {
    render(<MemoryRouter><HotelCard hotel={hotel} onSelect={vi.fn()} /></MemoryRouter>);
    expect(screen.getByText("Grand Palace Hotel")).toBeInTheDocument();
    expect(screen.getByText("Location: Chennai")).toBeInTheDocument();
    expect(screen.getByText("₹5000 / night")).toBeInTheDocument();
  });
});
