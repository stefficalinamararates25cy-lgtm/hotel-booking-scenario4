import { describe, it, expect } from "vitest";
import { filterHotels, calculateBookingCost, validateGuest } from "../bookingUtils.js";

const hotels = [
  { id: 1, name: "Grand Palace Hotel", location: "Chennai", rating: 5, price: 5000, amenities: ["WiFi", "Pool"] },
  { id: 2, name: "Green Valley Resort", location: "Ooty", rating: 4, price: 3500, amenities: ["WiFi", "Parking"] },
  { id: 3, name: "City Comfort Inn", location: "Coimbatore", rating: 3, price: 1800, amenities: ["Parking"] },
];

describe("Hotel card and details data", () => {
  it("keeps hotel names and details available for cards", () => {
    expect(hotels[0].name).toBe("Grand Palace Hotel");
    expect(hotels[0].location).toBe("Chennai");
    expect(hotels[0].amenities).toContain("Pool");
  });
});

describe("Hotel search and filtering", () => {
  it("searches hotel names and locations without case sensitivity", () => {
    expect(filterHotels(hotels, { search: "CHENNAI" }).map(h => h.id)).toEqual([1]);
  });
  it("filters by maximum price, rating and amenities", () => {
    expect(filterHotels(hotels, { maxPrice: 4000, rating: 4, amenities: ["WiFi"] }).map(h => h.id)).toEqual([2]);
  });
  it("returns an empty list when no hotel matches", () => {
    expect(filterHotels(hotels, { search: "Madurai" })).toEqual([]);
  });
});

describe("Room selection and booking cost", () => {
  it("calculates room subtotal, 12% tax and service charge", () => {
    expect(calculateBookingCost(5000, 1.3, 2)).toEqual({ subtotal: 13000, tax: 1560, serviceCharge: 200, total: 14760 });
  });
  it("clamps invalid night counts to at least one", () => {
    expect(calculateBookingCost(1000, 1, 0).subtotal).toBe(1000);
  });
  it("validates guest name and email", () => {
    expect(validateGuest("Kavi", "kavi@example.com")).toBe(true);
    expect(validateGuest("", "bad-email")).toBe(false);
  });
});

describe("Booking confirmation and cancellation", () => {
  it("adds a confirmed booking and removes a cancelled booking immutably", () => {
    const original = [{ bookingId: "SE1" }, { bookingId: "SE2" }];
    const confirmed = [...original, { bookingId: "SE3" }];
    const afterCancel = confirmed.filter((booking) => booking.bookingId !== "SE2");
    expect(confirmed).toHaveLength(3);
    expect(afterCancel.map(b => b.bookingId)).toEqual(["SE1", "SE3"]);
    expect(original).toHaveLength(2);
  });
});
