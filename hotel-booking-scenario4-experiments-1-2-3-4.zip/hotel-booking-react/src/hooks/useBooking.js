
import { useBooking as useBookingContext } from "../context/BookingContext";

export default function useBooking() {
  return useBookingContext();
}
