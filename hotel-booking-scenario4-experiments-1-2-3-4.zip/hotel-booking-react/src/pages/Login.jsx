
import { useEffect, useState } from "react";
import "./App.css";

function bookingMiddleware(action, next) {
  console.log("Booking action:", action.type);
  return next(action);
}

function App() {
  const [hotels, setHotels] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedHotel, setSelectedHotel] = useState(null);

  const [booking, setBooking] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("hotelBooking")) || {
        hotel: null,
        room: "Standard",
        checkIn: "",
        checkOut: "",
        guests: 1
      };
    } catch {
      return {
        hotel: null,
        room: "Standard",
        checkIn: "",
        checkOut: "",
        guests: 1
      };
    }
  });

  useEffect(() => {
    async function fetchHotels() {
      try {
        const response = await fetch(
          "https://jsonplaceholder.typicode.com/posts"
        );

        if (!response.ok) {
          throw new Error("Failed to fetch hotel data");
        }

        const data = await response.json();

        setHotels(
          data.slice(0, 10).map((item) => ({
            id: item.id,
            name: "Hotel " + item.id,
            location: item.id % 2 === 0 ? "Chennai" : "Ooty",
            price: 1500 + item.id * 300,
            available: item.id % 3 !== 0,
            room: ["Standard", "Deluxe", "Suite"][item.id % 3],
            description: item.title
          }))
        );
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchHotels();
  }, []);

  function updateBooking(action, changes) {
    bookingMiddleware(action, () => {
      setBooking((previous) => {
        const updated = { ...previous, ...changes };
        localStorage.setItem("hotelBooking", JSON.stringify(updated));
        return updated;
      });
    });
  }

  const filteredHotels = hotels.filter(
    (hotel) =>
      hotel.location.toLowerCase().includes(search.toLowerCase()) &&
      hotel.available
  );

  const days =
    booking.checkIn && booking.checkOut
      ? Math.max(
          0,
          Math.ceil(
            (new Date(booking.checkOut) -
              new Date(booking.checkIn)) /
              (1000 * 60 * 60 * 24)
          )
        )
      : 0;

  const roomRates = {
    Standard: 1,
    Deluxe: 1.5,
    Suite: 2
  };

  const roomCost = booking.hotel
    ? booking.hotel.price * roomRates[booking.room] * days
    : 0;

  const tax = roomCost * 0.12;
  const total = roomCost + tax;

  if (loading) return <h2>Loading hotels...</h2>;
  if (error) return <h2>Error: {error}</h2>;

  return (
    <div className="container">
      <h1>Hotel Booking Application</h1>

      <input
        placeholder="Search by location..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <h2>Available Hotels</h2>

      <div className="hotel-list">
        {filteredHotels.map((hotel) => (
          <div className="hotel-card" key={hotel.id}>
            <h3>{hotel.name}</h3>
            <p>Location: {hotel.location}</p>
            <p>Price: ₹{hotel.price} per night</p>
            <p>Availability: Available</p>

            <button onClick={() => setSelectedHotel(hotel)}>
              View Details
            </button>

            <button
              onClick={() =>
                updateBooking(
                  { type: "SELECT_HOTEL" },
                  { hotel, room: "Standard" }
                )
              }
            >
              Select Hotel
            </button>
          </div>
        ))}
      </div>

      {selectedHotel && (
        <div className="details">
          <h2>Hotel Details</h2>
          <p>{selectedHotel.name}</p>
          <p>{selectedHotel.location}</p>
          <p>{selectedHotel.description}</p>
          <button onClick={() => setSelectedHotel(null)}>
            Close Details
          </button>
        </div>
      )}

      <div className="details">
        <h2>Booking Details</h2>

        <p>
          Selected Hotel: {booking.hotel?.name || "Select a hotel first"}
        </p>

        <label>Room Type: </label>
        <select
          value={booking.room}
          onChange={(e) =>
            updateBooking(
              { type: "SELECT_ROOM" },
              { room: e.target.value }
            )
          }
        >
          <option value="Standard">Standard</option>
          <option value="Deluxe">Deluxe</option>
          <option value="Suite">Suite</option>
        </select>

        <p>Check-in Date</p>
        <input
          type="date"
          value={booking.checkIn}
          onChange={(e) =>
            updateBooking(
              { type: "SET_CHECK_IN" },
              { checkIn: e.target.value }
            )
          }
        />

        <p>Check-out Date</p>
        <input
          type="date"
          min={booking.checkIn || undefined}
          value={booking.checkOut}
          onChange={(e) =>
            updateBooking(
              { type: "SET_CHECK_OUT" },
              { checkOut: e.target.value }
            )
          }
        />

        <p>Number of Guests</p>
        <input
          type="number"
          min="1"
          max="10"
          value={booking.guests}
          onChange={(e) =>
            updateBooking(
              { type: "SET_GUESTS" },
              { guests: Math.max(1, Number(e.target.value)) }
            )
          }
        />

        <h3>Stay Duration: {days} night(s)</h3>
        <p>Room Cost: ₹{roomCost.toFixed(2)}</p>
        <p>Tax (12%): ₹{tax.toFixed(2)}</p>
        <h3>Total Amount: ₹{total.toFixed(2)}</h3>

        <button
          onClick={() => {
            if (!booking.hotel || days <= 0) {
              alert("Select a hotel and valid dates.");
              return;
            }
            alert("Booking details saved successfully!");
          }}
        >
          Confirm Booking
        </button>
      </div>
    </div>
  );
}

export default App;
