import { useState } from "react";

function Login({ onLogin, onBack }) {
  const [username, setUsername] = useState("emilys");
  const [password, setPassword] = useState("emilyspass");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function submit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const response = await fetch("https://dummyjson.com/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password, expiresInMins: 30 }),
      });
      const data = await response.json();
      if (!response.ok || !data.accessToken) throw new Error(data.message || "Login failed. Check credentials and internet connection.");
      sessionStorage.setItem("accessToken", data.accessToken);
      sessionStorage.setItem("authUser", JSON.stringify({ username: data.username, firstName: data.firstName }));
      onLogin(data);
    } catch (err) {
      setError(err.message || "Unable to login.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="form-card">
      <h2>Login to StayEasy</h2>
      <p>Demo credentials are prefilled. Internet connection is required.</p>
      <form onSubmit={submit}>
        <label>Username<input value={username} onChange={(e) => setUsername(e.target.value)} required /></label>
        <label>Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required /></label>
        {error && <p role="alert" style={{ color: "crimson" }}>{error}</p>}
        <button type="submit" disabled={loading}>{loading ? "Signing in..." : "Login"}</button>
        <button type="button" className="secondary" onClick={onBack}>Back</button>
      </form>
    </section>
  );
}


export default Login;
