
import { Link } from "react-router-dom";
import { useBooking } from "../context/BookingContext";

function Bookings() {
  const { confirmed, clearBooking } = useBooking();

  if (!confirmed) {
    return (
      <main className="container panel">
        <h1>My Bookings</h1>
        <p>Your booking is empty.</p>
        <Link to="/hotels">Find a hotel</Link>
      </main>
    );
  }

  return (
    <main className="container panel">
      <h1>My Bookings</h1>
      <p>Guest: {confirmed.name}</p>
      <p>Hotel: {confirmed.hotel}</p>
      <p>Room: {confirmed.room}</p>
      <p>Reference: {confirmed.reference || "Confirmed"}</p>
      <p>Total: ₹{confirmed.total}</p>
      <button onClick={clearBooking}>Clear Booking</button>
    </main>
  );
}

export default Bookings;
