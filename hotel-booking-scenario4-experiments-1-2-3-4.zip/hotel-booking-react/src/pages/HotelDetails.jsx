
import { useNavigate, useParams } from "react-router-dom";

const hotels = [
  {
    id: "1",
    name: "Grand Palace Hotel",
    location: "Chennai",
    rating: "5 Star",
    price: 5000
  },
  {
    id: "2",
    name: "Green Valley Resort",
    location: "Ooty",
    rating: "4 Star",
    price: 3500
  },
  {
    id: "3",
    name: "City Comfort Inn",
    location: "Coimbatore",
    rating: "3 Star",
    price: 1800
  },
  {
    id: "4",
    name: "Marina Beach Hotel",
    location: "Chennai",
    rating: "4 Star",
    price: 3200
  },
  {
    id: "5",
    name: "Mountain View Stay",
    location: "Kodaikanal",
    rating: "5 Star",
    price: 6000
  }
];

export default function HotelDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const hotel = hotels.find((item) => item.id === id);

  if (!hotel) {
    return (
      <div>
        <h2>Hotel Not Found</h2>
        <button onClick={() => navigate("/hotels")}>
          Back to Hotels
        </button>
      </div>
    );
  }

  return (
    <div style={{ padding: "30px", fontFamily: "Arial" }}>
      <button onClick={() => navigate("/hotels")}>
        Back to Hotels
      </button>

      <h1>{hotel.name}</h1>
      <p>Location: {hotel.location}</p>
      <p>Rating: {hotel.rating}</p>
      <h2>₹{hotel.price} / night</h2>

      <button
        onClick={() =>
          navigate("/booking/room", {
            state: { hotel }
          })
        }
      >
        Select Room
      </button>
    </div>
  );
}
