
import { Outlet, NavLink } from "react-router-dom";

function Booking() {
  return (
    <main className="container">
      <h1>Your Reservation</h1>
      <div className="steps">
        <NavLink to="/booking/room">1. Select Room</NavLink>
        <NavLink to="/booking/guest">2. Guest Details</NavLink>
        <NavLink to="/booking/summary">3. Summary</NavLink>
      </div>
      <Outlet />
    </main>
  );
}

export default Booking;
