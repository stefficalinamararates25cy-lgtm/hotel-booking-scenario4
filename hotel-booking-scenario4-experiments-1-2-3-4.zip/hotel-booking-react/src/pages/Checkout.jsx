
import Payment from "../components/Payment";

function Checkout() {
  return (
    <main className="container">
      <Payment />
    </main>
  );
}

export default Checkout;
